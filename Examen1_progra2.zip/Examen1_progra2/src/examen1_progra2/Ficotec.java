/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1_progra2;

import java.util.Scanner;

/**
 *
 * @author ferna
 */
public class Ficotec {
    public static void main(String[] args) {
            Scanner sc= new Scanner(System.in);
            while(1<2){
            System.out.println("Ingrese un numero para ingresar a una de las siguientes funciones: \n1)Agregar Cuenta "
                    + "\n2)Desactivar Cuenta"+"\n3)Aplicar Intereses"+"\n4)Transferir");
            
            int opcion= sc.nextInt();
            
            switch(opcion){
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:   
                    break;
            }}
    }
}
