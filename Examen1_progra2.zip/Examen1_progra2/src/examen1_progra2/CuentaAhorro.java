/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1_progra2;

import java.time.Instant;
import java.util.Date;

/**
 *
 * @author ferna
 */
public class CuentaAhorro extends CuentaBancaria {
    public Date date= new Date();
    public boolean activa;
    public CuentaAhorro(int n_cuenta, String name){
        super(n_cuenta,name);
        date=Date.from(Instant.MIN);
        activa=true;
        
    }
    @Override
    public void deposito(double m){
        if(activa){
            super.deposito(m);
        }
        else{
            super.deposito(m*0.9);
        }
    }
    public boolean retiro(double m){
        if(activa){
            saldo-=m;
            return true;
        }
        else{
            activa=true;
            return false;
        }
    }
    @Override
    public final void desactivar(){
        
    }
    public String toString(){
        if(activa)
        return super.toString()+" Estado: ACTIVA";
        else return super.toString()+" Estado: DESACTIVADA";
    }
}
