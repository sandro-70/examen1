/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1_progra2;

/**
 *
 * @author ferna
 */
public final class CuentaPlazoFijo extends CuentaBancaria {
   public double intereses;
   public static final double TASA=0.2;
   public CuentaPlazoFijo(int n_cuenta, String name){
       super(n_cuenta,name);
       intereses=0;
       
   }
   public boolean retiro(double m){
       if(m<=intereses){
           intereses-=m;
           return true;
       }
       return false;
       
   }
   public void desactivar(){
       
   }
   
   
   
}
