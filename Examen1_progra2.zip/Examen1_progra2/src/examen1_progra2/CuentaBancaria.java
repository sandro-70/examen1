/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1_progra2;

/**
 *
 * @author ferna
 */
public abstract class CuentaBancaria {
    protected int n_cuenta;
    protected String name;
    protected double saldo;

    public CuentaBancaria(int n_cuenta, String name) {
        this.n_cuenta = n_cuenta;
        this.name = name;
        saldo=500;
    }
    public void deposito(double m){
        saldo+=m;
    }
    public abstract boolean retiro(double m);
    
    public String toString(){
        return "Numero de cuenta: "+n_cuenta+" Nombre: "+name+" Saldo: "+saldo;
    }
    public abstract void desactivar();
    
}
