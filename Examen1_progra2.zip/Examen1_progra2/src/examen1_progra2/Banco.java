/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1_progra2;

import java.util.ArrayList;

/**
 *
 * @author ferna
 */
public class Banco {
    public ArrayList<CuentaBancaria> cuentas;
    
    
    public CuentaBancaria search(int nc,int n){
        if(n<cuentas.size()){
            if(nc==cuentas.get(n).n_cuenta)
                return cuentas.get(n);
                return search(nc,n+1);}
        return null;
    }
    public enum TipoCuenta{
       AHORRO,CHEQUE;
   }
    public void add(int num, String cliente,TipoCuenta tipo){
        if(search(num,0)==null){
            if(tipo.equals(tipo.AHORRO)){
                CuentaBancaria cuenta= new CuentaAhorro(num,cliente);
                cuentas.add(cuenta);
            }
            else if(tipo.equals(tipo.CHEQUE)){
                CuentaBancaria cuenta= new CuentaPlazoFijo(num,cliente);
                cuentas.add(cuenta);
            }
            
            
        }
    }
    public void evalDeactivations(int n){
        if(n<cuentas.size()){
            if(cuentas.get(n).toString().contains("Estado")){
                cuentas.get(n).desactivar();
            }
        }
    }
    public void applyInterests(){
        
    }
    public boolean transfer(int nc1,int nc2,double monto){
        if(search(nc1,0)!=null&&search(nc2,0)!=null){
            if(search(nc1,0).retiro(monto)){
            search(nc2,0).deposito(monto);
            return true;}
            
        }
        return false;
    }
}
