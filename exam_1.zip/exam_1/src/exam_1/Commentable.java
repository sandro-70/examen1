/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exam_1;

/**
 *
 * @author ferna
 */
public interface Commentable {
    boolean addComment(Comment comment);
}
